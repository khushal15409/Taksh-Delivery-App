import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:delivery_boy/core/constants/app_colors.dart';
import 'package:delivery_boy/data/models/order_model.dart';
import './summary_list_controller.dart';

class SummaryDetailScreen extends GetView<SummaryDetailController> {
  const SummaryDetailScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Obx(() {
      final shipment = controller.rxShipment.value ?? controller.initialShipment;
      
      // Get actual status from orderStatus, with fallback to initial status badge
      final responseStatus = shipment.orderStatus?.toUpperCase();
      final displayStatus = responseStatus ?? 'DISPATCH';

      Color statusColor;
      switch (displayStatus) {
        case 'SUCCESS':
        case 'DELIVERED':
          statusColor = Colors.green;
          break;
        case 'FAILED':
        case 'CANCELLED':
        case 'RETURNED':
          statusColor = Colors.red;
          break;
        default:
          statusColor = AppColors.primary;
      }

      return Scaffold(
        backgroundColor: const Color(0xFFF8F9FE),
        appBar: AppBar(
          backgroundColor: Colors.white,
          elevation: 0,
          leading: IconButton(
            icon: const Icon(Icons.arrow_back_ios, color: AppColors.textPrimary, size: 20),
            onPressed: () => Get.back(),
          ),
          title: const Text(
            "Order Detailed View",
            style: TextStyle(color: AppColors.textPrimary, fontWeight: FontWeight.bold),
          ),
          centerTitle: true,
        ),
        body: Column(
          children: [
            Expanded(
              child: SingleChildScrollView(
                physics: const BouncingScrollPhysics(),
                padding: const EdgeInsets.all(20),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    // Header Info Card (Order ID & Tracking ID)
                    _buildHeaderCard(shipment, statusColor, displayStatus),
                    const SizedBox(height: 20),

                    // Customer Section (No icons)
                    _buildSectionTitle("CUSTOMER INFORMATION"),
                    const SizedBox(height: 10),
                    _buildCustomerCard(shipment),
                    const SizedBox(height: 20),

                    // Product Items Section
                    _buildSectionTitle("PRODUCT ITEMS"),
                    const SizedBox(height: 10),
                    ... (shipment.items ?? []).map((item) => _buildProductItem(item)),
                    
                    if (shipment.items == null || shipment.items!.isEmpty)
                      _buildEmptyState("No items found in this order"),

                    const SizedBox(height: 30),
                  ],
                ),
              ),
            ),
          ],
        ),
      );
    });
  }

  Widget _buildSectionTitle(String title) {
    return Padding(
      padding: const EdgeInsets.only(left: 4, bottom: 4),
      child: Text(
        title,
        style: TextStyle(
          fontSize: 12,
          fontWeight: FontWeight.bold,
          color: Colors.grey.shade600,
          letterSpacing: 1.1,
        ),
      ),
    );
  }

  Widget _buildHeaderCard(OrderModel shipment, Color statusColor, String status) {
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.all(20),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(16),
        boxShadow: [
          BoxShadow(color: Colors.black.withOpacity(0.05), blurRadius: 10, offset: const Offset(0, 4)),
        ],
      ),
      child: Column(
        children: [
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    "Order ID: ${shipment.id ?? '-'}",
                    style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 18, color: AppColors.textPrimary),
                  ),
                  const SizedBox(height: 4),
                  Text(
                    "Tracking: ${shipment.orderNumber ?? '-'}",
                    style: const TextStyle(color: AppColors.textSecondary, fontSize: 15, fontWeight: FontWeight.w500),
                  ),
                ],
              ),
              Container(
                padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
                decoration: BoxDecoration(
                  color: statusColor.withOpacity(0.1),
                  borderRadius: BorderRadius.circular(8),
                  border: Border.all(color: statusColor.withOpacity(0.3)),
                ),
                child: Text(
                  status,
                  style: TextStyle(color: statusColor, fontWeight: FontWeight.bold, fontSize: 13),
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }

  Widget _buildCustomerCard(OrderModel shipment) {
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(16),
        boxShadow: [
          BoxShadow(color: Colors.black.withOpacity(0.04), blurRadius: 10, offset: const Offset(0, 4)),
        ],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              const Icon(Icons.person_outline, color: AppColors.primary, size: 20),
              const SizedBox(width: 8),
              Text(
                shipment.customer?.name ?? 'Customer',
                style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 16),
              ),
            ],
          ),
          const SizedBox(height: 12),
          Row(
            children: [
              const Icon(Icons.phone_outlined, color: Colors.green, size: 18),
              const SizedBox(width: 8),
              Text(shipment.customer?.mobile ?? '-', style: const TextStyle(color: AppColors.textSecondary, fontSize: 14)),
            ],
          ),
          const Padding(
            padding: EdgeInsets.symmetric(vertical: 12),
            child: Divider(height: 1),
          ),
          Row(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              const Icon(Icons.location_on_outlined, color: Colors.redAccent, size: 18),
              const SizedBox(width: 8),
              Expanded(
                child: Text(
                  _buildAddressString(shipment),
                  style: const TextStyle(color: AppColors.textSecondary, fontSize: 14, height: 1.4),
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }

  Widget _buildProductItem(OrderItemModel item) {
    String? imageUrl;
    if (item.productImages != null && item.productImages!.isNotEmpty) {
      imageUrl = item.productImages!.first.imageUrl;
    }

    return Container(
      margin: const EdgeInsets.only(bottom: 12),
      padding: const EdgeInsets.all(12),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: Colors.grey.shade100),
      ),
      child: Row(
        children: [
          // Product Image
          Container(
            width: 70,
            height: 70,
            decoration: BoxDecoration(
              color: Colors.grey.shade50,
              borderRadius: BorderRadius.circular(12),
            ),
            clipBehavior: Clip.antiAlias,
            child: (imageUrl != null && imageUrl.isNotEmpty)
                ? Image.network(imageUrl, fit: BoxFit.cover, 
                    errorBuilder: (c, e, s) => const Icon(Icons.image_not_supported, color: Colors.grey))
                : const Icon(Icons.inventory_2_outlined, color: Colors.grey),
          ),
          const SizedBox(width: 15),
          // Product Details
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  item.productName ?? 'Product',
                  style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 15, color: AppColors.textPrimary),
                  maxLines: 2,
                  overflow: TextOverflow.ellipsis,
                ),
                const SizedBox(height: 4),
                Text(
                  "Qty: ${item.quantity ?? 1}",
                  style: TextStyle(color: Colors.grey.shade600, fontSize: 13, fontWeight: FontWeight.w500),
                ),
              ],
            ),
          ),
          const SizedBox(width: 10),
          Text(
            "₹${item.variantPrice ?? 0.0}",
            style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 15, color: AppColors.primary),
          ),
        ],
      ),
    );
  }

  Widget _buildEmptyState(String msg) {
    return Center(
      child: Padding(
        padding: const EdgeInsets.all(40.0),
        child: Column(
          children: [
            const Icon(Icons.inbox_outlined, size: 48, color: Colors.grey),
            const SizedBox(height: 10),
            Text(msg, style: TextStyle(color: Colors.grey.shade400)),
          ],
        ),
      ),
    );
  }

  String _buildAddressString(OrderModel shipment) {
    final addr = shipment.deliveryAddress;
    if (addr == null) return 'Address not available';
    final parts = [
      addr.addressLine1,
      addr.addressLine2,
      addr.area?.name,
      addr.city?.name,
      addr.state?.name,
      addr.pincode,
    ].where((e) => e != null && e.toString().isNotEmpty).toList();
    return parts.join(', ');
  }
}
