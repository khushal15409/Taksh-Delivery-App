import 'package:flutter/material.dart';
import 'package:get/get.dart';
import '../quick_flow_controller.dart';

class QuickSummaryView extends GetView<QuickFlowController> {
  const QuickSummaryView({super.key});

  @override
  Widget build(BuildContext context) {
    return SingleChildScrollView(
      padding: const EdgeInsets.all(16.0),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          _buildOrderSummaryTable(),
          const SizedBox(height: 24),
          _buildCollectionDetailsCard(),
          const SizedBox(height: 100), // Space for bottom nav
        ],
      ),
    );
  }

  Widget _buildOrderSummaryTable() {
    return Container(
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(15),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(0.05),
            blurRadius: 10,
            offset: const Offset(0, 4),
          ),
        ],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const Padding(
            padding: EdgeInsets.all(16.0),
            child: Text(
              "Order Summary",
              style: TextStyle(
                fontSize: 18,
                fontWeight: FontWeight.bold,
                color: Color(0xFF333333),
              ),
            ),
          ),
          const Divider(height: 1),
          SingleChildScrollView(
            scrollDirection: Axis.horizontal,
            child: DataTable(
              columnSpacing: 25,
              headingRowHeight: 45,
              dataRowHeight: 55,
              columns: const [
                DataColumn(label: Text('Category', style: TextStyle(fontWeight: FontWeight.bold, color: Colors.grey))),
                DataColumn(label: Text('Desp', style: TextStyle(fontWeight: FontWeight.bold, color: Colors.grey))),
                DataColumn(label: Text('Succ', style: TextStyle(fontWeight: FontWeight.bold, color: Colors.grey))),
                DataColumn(label: Text('Fail', style: TextStyle(fontWeight: FontWeight.bold, color: Colors.grey))),
                DataColumn(label: Text('Rate %', style: TextStyle(fontWeight: FontWeight.bold, color: Colors.grey))),
              ],
              rows: [
                _buildDataRow('Quick', '20', '15', '5', '75.00%', isBold: true),
              ],
            ),
          ),
          const SizedBox(height: 8),
        ],
      ),
    );
  }

  DataRow _buildDataRow(String category, String desp, String succ, String fail, String rate, {bool isBold = false}) {
    final style = TextStyle(
      fontWeight: isBold ? FontWeight.bold : FontWeight.normal,
      fontSize: 14,
      color: const Color(0xFF333333),
    );

    return DataRow(cells: [
      DataCell(Text(category, style: style)),
      DataCell(Text(desp, style: style.copyWith(color: Colors.blue.shade700))),
      DataCell(Text(succ, style: style.copyWith(color: Colors.green.shade600))),
      DataCell(Text(fail, style: style.copyWith(color: Colors.red.shade600))),
      DataCell(Text(rate, style: style.copyWith(color: const Color(0xFF546E7A)))),
    ]);
  }

  Widget _buildCollectionDetailsCard() {
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.all(20),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(15),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(0.05),
            blurRadius: 10,
            offset: const Offset(0, 4),
          ),
        ],
      ),
      child: Column(
        children: [
          const Text(
            "Collection Details",
            style: TextStyle(
              fontSize: 18,
              fontWeight: FontWeight.bold,
              color: Color(0xFF333333),
            ),
          ),
          const SizedBox(height: 12),
          const Divider(),
          const SizedBox(height: 16),
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceAround,
            children: [
              _buildMetricItem("Total", "₹18270.7", Colors.blue.shade700),
              _buildMetricItem("Cash", "₹18270.7", Colors.green.shade600),
              _buildMetricItem("Online", "₹0", Colors.orange.shade700),
            ],
          ),
        ],
      ),
    );
  }

  Widget _buildMetricItem(String label, String value, Color color) {
    return Column(
      children: [
        Text(
          label,
          style: const TextStyle(
            color: Colors.grey,
            fontSize: 13,
            fontWeight: FontWeight.w500,
          ),
        ),
        const SizedBox(height: 8),
        Text(
          value,
          style: TextStyle(
            color: color,
            fontSize: 16,
            fontWeight: FontWeight.bold,
          ),
        ),
      ],
    );
  }
}
