import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:pinput/pinput.dart';
import 'package:delivery_boy/presentation/screens/home/quick/quick_flow_controller.dart';
import 'package:delivery_boy/core/constants/app_colors.dart';

class QuickMarkUndeliveredScreen extends GetView<QuickFlowController> {
  const QuickMarkUndeliveredScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return PopScope(
      canPop: true,
      onPopInvoked: (didPop) {
        if (didPop) {
          controller.hideLoading();
        }
      },
      child: Scaffold(
        backgroundColor: Colors.white,
        appBar: AppBar(
          title: const Text("Mark Undelivered",
              style: TextStyle(
                  color: Colors.black,
                  fontWeight: FontWeight.bold)),
          backgroundColor: Colors.white,
          elevation: 0,
          leading: IconButton(
            icon: const Icon(Icons.arrow_back, color: Colors.black),
            onPressed: () => controller.previousMarkPendingStep(),
          ),
        ),
        body: Obx(() {
          switch (controller.currentStep.value) {
            case QuickStep.markPendingCustomerCancelReasons:
              return _buildReasonsView(context);
            case QuickStep.markPendingCustomerCancelOtp:
              return _buildOtpView(context);
            case QuickStep.markPendingCustomerCancelDetails:
              return _buildDetailsView(context);
            case QuickStep.markPendingCustomerCancelImages:
              return _buildImagesView(context);
            default:
              return const Center(child: CircularProgressIndicator());
          }
        }),
      ),
    );
  }

  Widget _buildReasonsView(BuildContext context) {
    final width = MediaQuery.of(context).size.width;
    return Column(
      children: [
        Expanded(
          child: SingleChildScrollView(
            padding: const EdgeInsets.all(20),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const Text("SELECT CANCELLATION REASON",
                    style:
                        TextStyle(fontWeight: FontWeight.bold, fontSize: 16)),
                const SizedBox(height: 15),
                Obx(() => Column(
                      children: controller.customerCancelReasons.map((reason) {
                        final id = reason['id'].toString();
                        final name =
                            (reason['reason'] ?? reason['name'] ?? "").toString();
                        return Obx(() => RadioListTile<String>(
                              title: Text(name.toUpperCase(),
                                  style: const TextStyle(fontSize: 14)),
                              value: id,
                              groupValue:
                                  controller.selectedCustomerCancelReasonId.value,
                              onChanged: (val) {
                                if (val != null) {
                                  controller.selectedCustomerCancelReasonId.value =
                                      val;
                                }
                              },
                              activeColor: AppColors.primary,
                              contentPadding: EdgeInsets.zero,
                            ));
                      }).toList(),
                    )),
              ],
            ),
          ),
        ),
        _buildFooter(width, isReasons: true),
      ],
    );
  }

  Widget _buildOtpView(BuildContext context) {
    final width = MediaQuery.of(context).size.width;
    return Column(
      children: [
        Expanded(
          child: Padding(
            padding: const EdgeInsets.all(30),
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                const Icon(Icons.mark_email_unread_outlined, size: 80, color: AppColors.primary),
                const SizedBox(height: 30),
                const Text("VERIFY OTP",
                    style: TextStyle(fontWeight: FontWeight.bold, fontSize: 22)),
                const SizedBox(height: 15),
                const Text(
                  "PLEASE ENTER THE 4-DIGIT OTP PROVIDED BY THE CUSTOMER",
                  textAlign: TextAlign.center,
                  style: TextStyle(fontSize: 13, color: AppColors.textSecondary),
                ),
                const SizedBox(height: 40),
                Pinput(
                  length: 4,
                  controller: controller.customerCancelOtpController,
                  onChanged: (val) => controller.customerCancelOtpText.value = val,
                  defaultPinTheme: PinTheme(
                    width: 60,
                    height: 65,
                    textStyle: const TextStyle(fontSize: 24, fontWeight: FontWeight.bold),
                    decoration: BoxDecoration(
                      color: Colors.grey.shade50,
                      border: Border.all(color: Colors.grey.shade300),
                      borderRadius: BorderRadius.circular(15),
                    ),
                  ),
                ),
              ],
            ),
          ),
        ),
        _buildFooter(width, isOtp: true),
      ],
    );
  }

  Widget _buildDetailsView(BuildContext context) {
    final width = MediaQuery.of(context).size.width;
    return Column(
      children: [
        Expanded(
          child: SingleChildScrollView(
            padding: const EdgeInsets.all(20),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const Text("ADDITIONAL DETAILS",
                    style:
                        TextStyle(fontWeight: FontWeight.bold, fontSize: 16)),
                const SizedBox(height: 15),
                const Text("PLEASE PROVIDE MORE INFORMATION ABOUT THE CANCELLATION (OPTIONAL)",
                    style: TextStyle(fontSize: 13, color: AppColors.textSecondary)),
                const SizedBox(height: 20),
                TextField(
                  controller: controller.customerCancelCommentController,
                  maxLines: 5,
                  decoration: InputDecoration(
                    hintText: "Enter reason details here...",
                    filled: true,
                    fillColor: Colors.grey.shade50,
                    border: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(12),
                      borderSide: BorderSide(color: Colors.grey.shade300),
                    ),
                    focusedBorder: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(12),
                      borderSide: const BorderSide(color: AppColors.primary, width: 2),
                    ),
                  ),
                ),
              ],
            ),
          ),
        ),
        _buildFooter(width, isDetails: true),
      ],
    );
  }

  Widget _buildImagesView(BuildContext context) {
    // This step is now bypassed for direct OTP flow, but kept for consistency
    return const Center(child: Text("Bypassed Step"));
  }

  Widget _buildFooter(double width,
      {bool isReasons = false,
      bool isOtp = false,
      bool isDetails = false}) {
    return Container(
      padding: const EdgeInsets.all(20),
      decoration: BoxDecoration(color: Colors.white, boxShadow: [
        BoxShadow(
            color: Colors.black.withOpacity(0.05),
            blurRadius: 10,
            offset: const Offset(0, -5))
      ]),
      child: Row(
        children: [
          Expanded(
            child: OutlinedButton(
              onPressed: () => controller.previousMarkPendingStep(),
              style: OutlinedButton.styleFrom(
                padding: const EdgeInsets.symmetric(vertical: 15),
                side: const BorderSide(color: AppColors.textSecondary),
                shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(10)),
              ),
              child: const Text("BACK",
                  style: TextStyle(
                      color: AppColors.textSecondary,
                      fontWeight: FontWeight.bold)),
            ),
          ),
          const SizedBox(width: 15),
          Expanded(
            child: Obx(() {
              bool canPress = true;
              if (isReasons && controller.selectedCustomerCancelReasonId.value.isEmpty) canPress = false;
              if (isOtp && controller.customerCancelOtpText.value.length != 4) canPress = false;

              return ElevatedButton(
                onPressed: canPress ? () => controller.nextMarkPendingStep() : null,
                style: ElevatedButton.styleFrom(
                  backgroundColor: AppColors.primary,
                  padding: const EdgeInsets.symmetric(vertical: 15),
                  shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(10)),
                ),
                child: Text(
                    isOtp
                        ? "MARK UNDELIVERED"
                        : isDetails
                            ? "SUBMIT"
                            : "NEXT",
                    style: const TextStyle(
                        color: Colors.white, fontWeight: FontWeight.bold)),
              );
            }),
          ),
        ],
      ),
    );
  }
}
